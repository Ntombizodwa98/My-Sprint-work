from django.urls import path
from . import views

urlpatterns = [
    path('retail/', views.ecommerce_report_page, name='retail_report'),
    path('marketing/', views.marketing_report_page, name='marketing_report'),
]