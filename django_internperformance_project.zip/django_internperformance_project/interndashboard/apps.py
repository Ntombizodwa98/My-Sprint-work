from django.apps import AppConfig


class InterndashboardConfig(AppConfig):
    name = 'interndashboard'
